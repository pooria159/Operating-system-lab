#!bin/bash

if(( $2 > $1 )) 
then 
    echo $2 
    else 
    echo $1 
fi
